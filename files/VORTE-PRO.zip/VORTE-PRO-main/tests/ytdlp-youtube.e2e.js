// YouTube reliability: JS runtime / IPv4 flags, client fallbacks, self-updating yt-dlp, honest error messages.
// Uses a FAKE yt-dlp (no network). Run: node tests/ytdlp-youtube.e2e.js
const fs = require("fs"), os = require("os"), path = require("path");
let pass = 0, fail = 0;
const check = (n, ok, d) => { ok ? pass++ : fail++; console.log(`  ${ok ? "✅" : "❌"} ${n}${ok ? "" : " -> " + (typeof d === "string" ? d : JSON.stringify(d))}`); };
const section = (t) => console.log(`\n[${t}]`);

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fakeyt2-"));
const fake = path.join(dir, "yt-dlp");
const script = (version) => `#!/bin/sh
D="$(dirname "$0")"
echo "$*" >> "$D/calls.log"
case "$*" in *--version*) echo ${version}; exit 0;; esac
MODE=$(cat "$D/mode.txt" 2>/dev/null)
case "$*" in
  *youtube*|*youtu.be*)
    case "$MODE" in
      need_android_vr) case "$*" in *player_client=android_vr*) ;; *) echo "ERROR: [youtube] abc: Sign in to confirm you’re not a bot" >&2; exit 1;; esac;;
      always_botcheck) echo "ERROR: [youtube] abc: Sign in to confirm you’re not a bot" >&2; exit 1;;
      private) echo "ERROR: [youtube] abc: Private video. Sign in if you've been granted access" >&2; exit 1;;
    esac;;
  *tiktok*)
    if [ "$MODE" = "needs_update" ] && [ "${version}" = "2000.01.01" ]; then echo "ERROR: Unable to extract webpage video data" >&2; exit 1; fi;;
esac
out=""; prev=""; ext="mp4"
for a in "$@"; do [ "$prev" = "--output" ] && out="$a"; [ "$a" = "--extract-audio" ] && ext="mp3"; prev="$a"; done
out=$(printf '%s' "$out" | sed "s/%(ext)s/$ext/")
[ -n "$out" ] && echo data > "$out"
case "$*" in *--print*) printf '{"title": "Fake Title", "ext": "%s", "filepath": "%s"}\\n' "$ext" "$out";; esac
exit 0
`;
fs.writeFileSync(fake, script("2026.01.01"), { mode: 0o755 }); // a current yt-dlp
const mode = (m) => fs.writeFileSync(path.join(dir, "mode.txt"), m);
const calls = () => (fs.existsSync(path.join(dir, "calls.log")) ? fs.readFileSync(path.join(dir, "calls.log"), "utf8").trim().split("\n").filter((l) => !/--version/.test(l)) : []);
const reset = () => { try { fs.unlinkSync(path.join(dir, "calls.log")); } catch {} };
process.env.YTDLP_PATH = fake;
delete process.env.YTDLP_COOKIES;

const runner = require("../src/services/downloaders/ytdlpRunner");
const ytdlp = require("../src/services/downloaders/ytdlp");
const YT = "https://www.youtube.com/watch?v=abc";

(async () => {
  section("flags: JS runtime, IPv4, challenge solver");
  mode("");
  await ytdlp.downloadAudio(YT);
  let c = calls()[0] || "";
  check("this bot's own node is handed to yt-dlp by full path", c.includes(`--js-runtimes node:${process.execPath}`), c);
  check("IPv4 is forced", c.includes("--force-ipv4"), c);
  check("a yt-dlp the host provides may need the solver: remote component allowed", c.includes("--remote-components ejs:github"), c);
  reset(); process.env.YTDLP_IPV4 = "false"; process.env.YTDLP_JS_RUNTIME = "off";
  await ytdlp.downloadAudio(YT); c = calls()[0] || "";
  check("YTDLP_IPV4=false and YTDLP_JS_RUNTIME=off switch them off", !c.includes("--force-ipv4") && !c.includes("--js-runtimes"), c);
  reset(); process.env.YTDLP_JS_RUNTIME = "node:/opt/node22/bin/node"; delete process.env.YTDLP_IPV4;
  await ytdlp.downloadAudio(YT); c = calls()[0] || "";
  check("YTDLP_JS_RUNTIME can point at another runtime", c.includes("--js-runtimes node:/opt/node22/bin/node"), c);
  delete process.env.YTDLP_JS_RUNTIME;
  check("an old yt-dlp is not given flags it cannot know", runner.versionAtLeast("2025.12.1", "2025.11.12") && !runner.versionAtLeast("2025.06.30", "2025.11.12") && runner.versionAtLeast(null, "2025.11.12"));

  section("YouTube clients are tried one after another, only when refused");
  reset(); mode("need_android_vr");
  const r = await ytdlp.downloadAudio(YT);
  const seq = calls().map((l) => (l.match(/player_client=([\w,]+)/) || [null, "default"])[1]);
  check("the download succeeds on the client that is accepted", !!r.filePath && fs.existsSync(r.filePath), r);
  check("order: default, then tv/web_safari, then android_vr — and it STOPS there", JSON.stringify(seq) === JSON.stringify(["default", "tv,web_safari", "android_vr"]), seq);
  ytdlp.cleanup(r.filePath);

  reset(); mode("always_botcheck");
  let err = null; try { await ytdlp.downloadAudio(YT); } catch (e) { err = e; }
  check("every client refused -> a clear bot-check message", err && /bot check/.test(err.message), err?.message);
  check("...that says what to do about cookies on this host", err && /cookies/i.test(err.message), err?.message);
  check("all four clients were tried (and nothing else)", calls().length === 4, calls().length);

  reset(); mode("private");
  err = null; try { await ytdlp.downloadAudio(YT); } catch (e) { err = e; }
  check("a private video is reported as such and NOT retried on other clients", err && /private/i.test(err.message) && calls().length === 1, [err?.message, calls().length]);

  reset(); mode("always_botcheck");
  err = null; try { await ytdlp.downloadAudio("https://www.tiktok.com/@a/video/1"); } catch (e) { err = e; }
  check("non-YouTube links never go through the client chain", calls().length === 1, calls().length);

  section("client list can be changed or pinned");
  check("default list has four clients", ytdlp.clientVariants(YT, {}).length === 4);
  check("YTDLP_YT_CLIENTS overrides it", JSON.stringify(ytdlp.clientVariants(YT, { YTDLP_YT_CLIENTS: "player_client=a;player_client=b" })) === JSON.stringify([{ extractorArgs: "youtube:player_client=a" }, { extractorArgs: "youtube:player_client=b" }]));
  check("YTDLP_EXTRACTOR_ARGS pins the choice (no chain)", ytdlp.clientVariants(YT, { YTDLP_EXTRACTOR_ARGS: "youtube:player_client=mweb" }).length === 1);
  check("only YouTube links get the chain", ytdlp.clientVariants("https://www.tiktok.com/@a/video/1", {}).length === 1 && ytdlp.clientVariants("ytsearch5:hello", {}).length === 4);

  fs.writeFileSync(fake, script("2000.01.01"), { mode: 0o755 }); // from here on: an out-of-date build
  section("yt-dlp keeps itself current (only the copy the bot downloaded)");
  check("a yt-dlp the host provides is left alone", (await runner.updateNow({ force: true })).updated === false);
  runner.deps.managedPath = fake;               // pretend this file is the bot's own download
  let downloads = 0;
  runner.deps.latestTag = async () => "2099.02.02";
  runner.deps.download = async (url, dest) => { downloads++; fs.writeFileSync(dest, script("2099.02.02"), { mode: 0o755 }); };
  const u = await runner.updateNow();
  check("older than the latest release -> downloaded and replaced", u.updated === true && u.from === "2000.01.01" && u.to === "2099.02.02" && downloads === 1, u);
  const again = await runner.updateNow();
  check("already the latest -> nothing is downloaded", again.updated === false && /latest/.test(again.reason) && downloads === 1, again);
  const recent = await runner.updateNow({ minAgeMs: 60000 });
  check("a recent check is not repeated (no download loop)", recent.updated === false && downloads === 1, recent);
  runner.deps.latestTag = async () => null;
  const offline = await runner.updateNow({ force: false });
  check("GitHub unreachable -> no change, no crash", offline.updated === false, offline);
  const forced = await runner.updateNow({ force: true });
  check("send .dltest update (force) -> downloads anyway", forced.updated === true && downloads === 2, forced);

  section("a broken extractor heals itself by updating, once");
  fs.writeFileSync(fake, script("2000.01.01"), { mode: 0o755 });   // back to the stale build
  downloads = 0; reset(); mode("needs_update");
  runner.deps.latestTag = async () => "2099.02.02";
  runner.deps.download = async (url, dest) => { downloads++; fs.writeFileSync(dest, script("2099.02.02"), { mode: 0o755 }); };
  await runner.updateNow({ force: true }); // uses up this half-hour window? reset below by waiting is not possible, so make the stale build again
  fs.writeFileSync(fake, script("2000.01.01"), { mode: 0o755 });
  downloads = 0;
  // the previous call counts as "checked recently", so heal is allowed only when that window has passed: emulate by clearing it
  const rr = require("../src/services/downloaders/ytdlpRunner");
  rr._resetUpdateClock && rr._resetUpdateClock();
  const t = await ytdlp.downloadVideo("https://www.tiktok.com/@a/video/1", { platform: "tiktok" });
  check("tiktok 'unable to extract' on a stale yt-dlp -> updated, retried, works", !!t.filePath && downloads === 1, { downloads, t });
  ytdlp.cleanup(t.filePath);

  section("health report (.dltest)");
  const h = runner.health();
  check("reports node version, runtime and managed state", h.node === process.version && h.nodeOk === (Number(process.versions.node.split(".")[0]) >= 22) && typeof h.ipv4 === "boolean" && h.managed === true, h);

  fs.rmSync(dir, { recursive: true, force: true });
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error("TEST CRASHED:", e); process.exit(1); });
